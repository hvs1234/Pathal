<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <title>Pathaal - The Himalayan Way of Life</title>
    <meta name="description" content="Let us plan your holiday in Uttarakhand India. Explore Our Home Stays, Resorts & Camps in Exciting Destinations.">
    <link href="pathaal.com" rel="canonical" />
    <link href="favicon.png" rel="shortcut icon" />
    <!-- OG Tags -->
    <meta content="Pathaal - The Himalayan Way of Life" property="og:title" />
    <meta property="og:site_name" content="Pathaal">
    <meta content="https://pathaal.com/" property="og:url" />
    <link rel="canonical" href="https://pathaal.com/index.php" />
    <meta property="og:description" content="Let us plan your holiday in Uttarakhand India. Explore Our Home Stays, Resorts & Camps in Exciting Destinations.">
    <meta property="og:type" content="website">
    <meta content="https://pathaal.com/img/og-image.jpg" property="og:image" />
    <!-- End OG Tags -->
    <!-- CSS Files -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,700" rel="stylesheet" />
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    <link href="css/animate.css" rel="stylesheet" type="text/css" />
    <link href="css/datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="css/custom-plugins.css" rel="stylesheet" type="text/css" />
    <link href="css/theme-style.min.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
      header .navbar-nav>li:not(#menuFilterLoc):hover>.dropdown-menu {
      display: block;
      }
    </style>
  </head>
  <body class=" parent-hotel for-homepage explorer_chain">
    <main class="outer-page"> 
      <div class="loading-page">
        <div class="container">
          <div class="sep10"></div>
          <div class="main-logo text-center">
            <img src="img/logo-home.png">
          </div>
          <!-- <div class="sep10"></div> -->
          <div class="row clearfix">
            <div class="content_wrapper pb-0">
              <div class="no-gutter clearfix">
                <div class="">
                  <div class="three-col">
                    <div class="col-md-4">
                      <a href="homestays.php">
                        <img class="img-responsive" src="img/pathaal-homestays.jpg"/>
                        <h2>HomeStays</h2>
                        <p>Your Home in the Hills</p>
                      </a>
                      <div class="sep30"></div>
                    </div>
                    <div class="col-md-4">
                      <a href="javascript:;">
                        <div class="img">
                          <img class="img-responsive" src="img/pathaal-agro.png"/>
                          <div class="tag">Coming Soon</div> 
                        </div>
                        <h2>Pathaal Agro</h2>
                        <p>The Himalayan Flavours</p>
                      </a>
                      <div class="sep30"></div>
                    </div>
                    <div class="col-md-4">
                      <a href="javascript:;">
                        <div class="img">
                          <img class="img-responsive" src="img/turnkey-projects.png"/>
                          <div class="tag">Coming Soon</div> 
                        </div>
                        <h2>Renovation and Turnkey Projects</h2>
                      </a>
                      <div class="sep30"></div>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-md-9 text-content">
                  <div class="text-content-wrapper">
                    <h3 style="">
                      <i class="fa fa-quote-left"></i> &nbsp; Pathaal is our initiative in helping the curious souls live their dream by providing an opportunity to experience a simple, healthy life close to nature.
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="sep30"></div>
          <div class="sep30"></div>
          <div class="vector-img text-right">
            <img src="img/village-vector.png">
          </div>
        </div>
      </div>
    </main>

    <!-- Theme JavaScripts -->
    <script src="js/jssor.slider.min.js"></script>
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/jquery.viewportchecker.min.js" type="text/javascript"></script>
    <script src="js/datepicker.min.js" type="text/javascript"></script>
    <script src="js/custom.js"></script>
  </body>
</html>