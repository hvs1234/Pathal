$("#slider1").responsiveSlides({
        pager: true,
        speed: 500,
        namespace: "transparent-btns"
      });